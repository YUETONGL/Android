package com.example.listview;

public class Fruit {
    private String mFruitName;
    private int mImageID;

    public Fruit(String name,int imageId){
        this.mFruitName=name;
        this.mImageID=imageId;
    }

    public String getName(){
        return mFruitName;
    }

    public int getImageId(){
        return mImageID;
    }
}
