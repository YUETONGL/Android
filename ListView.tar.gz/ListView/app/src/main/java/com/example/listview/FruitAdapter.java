package com.example.listview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class FruitAdapter extends ArrayAdapter{
    private final int mResourceId;
    private View mView;
    private ViewHolder mViewHolder;

    public FruitAdapter(Context context, int textViewResourceId, List<Fruit> objects) {
        super(context, textViewResourceId, objects);
        mResourceId = textViewResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Fruit fruit = (Fruit) getItem(position);
        initView(convertView,parent);
        mViewHolder.mImageIV.setImageResource(fruit.getImageId());
        mViewHolder.mNameTV.setText(fruit.getName());
        return mView;
    }

    private void initView( View convertView, ViewGroup parent) {
        if(convertView==null) {
            mView = LayoutInflater.from(getContext()).inflate(mResourceId, parent,
                    false);
            mViewHolder=new ViewHolder();
            mViewHolder.mImageIV=(ImageView)mView.findViewById(R.id.fruit_image);
            mViewHolder.mNameTV=(TextView)mView.findViewById(R.id.fruit_name);
            mView.setTag(mViewHolder);
        }else{
            mView=convertView;
            mViewHolder=(ViewHolder)mView.getTag();
        }
    }

    class ViewHolder{
        ImageView mImageIV;
        TextView mNameTV;
    }

}