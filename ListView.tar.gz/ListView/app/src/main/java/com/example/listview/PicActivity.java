package com.example.listview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class PicActivity extends AppCompatActivity {
    private ImageView mFruitIV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pic);
        Intent intent=getIntent();
        initView();
        mFruitIV.setImageResource(intent.getIntExtra("fruit",-1));
    }

    private void initView() {
        mFruitIV=(ImageView) findViewById(R.id.image_view);
    }
}
