package com.example.listview;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends Activity {
    private List<Fruit> mFruitList = new ArrayList<>();
    private ListView mFruitLV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initFruits();
        initView();
        mFruitLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Fruit fruit=mFruitList.get(position);
                Intent intent=new Intent(MainActivity.this,PicActivity.class);
                intent.putExtra("fruit",fruit.getImageId());
                startActivity(intent);
            }
        });
    }

    private void initView() {
        mFruitLV = (ListView) findViewById(R.id.list_view);
        FruitAdapter adapter = new FruitAdapter(MainActivity.this, R.layout.fruit_item, mFruitList );
        mFruitLV.setAdapter(adapter);
    }

    private void initFruits(){
        Fruit apple=new Fruit(this.getString(R.string.apple),R.drawable.apple_pic);
        mFruitList.add(apple);
        Fruit apricot=new Fruit(this.getString(R.string.apricot),R.drawable.apricot_pic);
        mFruitList.add(apricot);
        Fruit avocado=new Fruit(this.getString(R.string.avocado),R.drawable.avocado_pic);
        mFruitList.add(avocado);
        Fruit blueberry=new Fruit(this.getString(R.string.blueberry),R.drawable.blueberry_pic);
        mFruitList.add(blueberry);
        Fruit cherry=new Fruit(this.getString(R.string.cherry),R.drawable.cherry_pic);
        mFruitList.add(cherry);
        Fruit coconut=new Fruit(this.getString(R.string.coconut),R.drawable.coconut_pic);
        mFruitList.add(coconut);
        Fruit lemon=new Fruit(this.getString(R.string.lemon),R.drawable.lemon_pic);
        mFruitList.add(lemon);
        Fruit mangosteen=new Fruit(this.getString(R.string.mangosteen),R.drawable.mangosteen_pic);
        mFruitList.add(mangosteen);
        Fruit pear=new Fruit(this.getString(R.string.pear),R.drawable.pear_pic);
        mFruitList.add(pear);
        Fruit pomegranate=new Fruit(this.getString(R.string.pomegranate),R.drawable.pomegranate_pic);
        mFruitList.add(pomegranate);
        Fruit rambutan=new Fruit(this.getString(R.string.rambutan),R.drawable.rambutan_pic);
        mFruitList.add(rambutan);
        Fruit strawberry=new Fruit(this.getString(R.string.strawberry),R.drawable.strawberry_pic);
        mFruitList.add(strawberry);
        Fruit watermelon=new Fruit(this.getString(R.string.watermelon),R.drawable.watermelon_pic);
        mFruitList.add(watermelon);
    }
}
