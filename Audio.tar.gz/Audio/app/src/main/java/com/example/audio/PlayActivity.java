package com.example.audio;

import android.Manifest;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class PlayActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String FILE_URL = "url";
    private static final String PER_DENIED = "Denied permission that cannot use application";
    private static final String PATTERN = "m:ss";
    private Handler mHandler = new Handler();
    private SeekBar mSB;
    private TextView mProgressTV;
    private Button mPlayBtn;
    private Button mStopBtn;
    private Button mPauseBtn;
    private MediaService.MyBinder mMyBinder;
    private Intent mMediaServiceIntent;
    private SimpleDateFormat time = new SimpleDateFormat(PATTERN, Locale.CHINA);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);
        Intent intent = getIntent();
        String path = intent.getStringExtra(FILE_URL);
        initView();
        initListener();
        mMediaServiceIntent = new Intent(this, MediaService.class);
        if (ContextCompat.checkSelfPermission(PlayActivity.this, Manifest.permission
                .WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(PlayActivity.this, new String[]{Manifest.permission
                    .WRITE_EXTERNAL_STORAGE}, 1);
        } else {
            mMediaServiceIntent.putExtra(FILE_URL, path);
            bindService(mMediaServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
        }
    }

    private void initView() {
        mPlayBtn = findViewById(R.id.play);
        mStopBtn = findViewById(R.id.stop);
        mPauseBtn = findViewById(R.id.pause);
        mSB = findViewById(R.id.seekbar);
        mProgressTV = findViewById(R.id.text1);
    }

    private void initListener() {
        mPlayBtn.setOnClickListener(this);
        mStopBtn.setOnClickListener(this);
        mPauseBtn.setOnClickListener(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[]
            grantResults) {
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager
                        .PERMISSION_GRANTED) {
                    bindService(mMediaServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
                } else {
                    Toast.makeText(this, PER_DENIED, Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
            }
            default:
                break;
        }
    }

    private ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mMyBinder = (MediaService.MyBinder) service;
            mSB.setMax(mMyBinder.getProgress());
            mSB.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if (fromUser) {
                        mMyBinder.seekToPositon(seekBar.getProgress());
                    }
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.play:
                mHandler.post(mRunnable);
                mMyBinder.playMusic();
                break;
            case R.id.pause:
                mHandler.removeCallbacks(mRunnable);
                mMyBinder.pauseMusic();
                break;
            case R.id.stop:
                mHandler.removeCallbacks(mRunnable);
                mMyBinder.resetMusic();
                break;
            default:
                break;
        }
    }

    private Runnable mRunnable = new Runnable() {
        @Override
        public void run() {
            mSB.setProgress(mMyBinder.getPlayPosition());
            mProgressTV.setText(time.format(mMyBinder.getPlayPosition()));
            mHandler.postDelayed(mRunnable, 1000);
        }
    };

    protected void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacks(mRunnable);
        mMyBinder.closeMedia();
        unbindService(mServiceConnection);
    }
}