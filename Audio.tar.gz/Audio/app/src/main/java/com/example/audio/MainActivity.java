package com.example.audio;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<String> list = new ArrayList<>();
    private static final String FILE_URL = "url";
    public static List<Song> allSongs = new ArrayList<Song>();
    private Message mMessage = new Message();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new Thread(new Runnable() {
            @Override
            public void run() {
                allSongs = MusicHelper.getAllSongs(MainActivity.this);
                mMessage.what = 0x11;
                handler.sendMessage(mMessage);
            }
        }).start();
    }

    final Handler handler = new Handler(Looper.myLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 0x11) {
                if (list.isEmpty()) {
                    setListView();
                }
            }
        }
    };

    private void setListView() {
        for (int i = 0; i < allSongs.size(); i++) {
            Song s = (Song) allSongs.get(i);
            list.add(s.getFilename());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R
                .layout.simple_list_item_1, list);
        ListView mLV = (ListView) findViewById(R.id.listview);
        mLV.setAdapter(adapter);
        mLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Song song = allSongs.get(position);
                Intent intent = new Intent(MainActivity.this, PlayActivity.class);
                intent.putExtra(FILE_URL, song.getFileUrl());
                startActivity(intent);
            }
        });
    }
}
