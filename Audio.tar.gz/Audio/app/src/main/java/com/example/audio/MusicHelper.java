package com.example.audio;

import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore;

import java.util.ArrayList;
import java.util.List;

public class MusicHelper {
    public static List<Song> songs = new ArrayList<Song>();

    public static List<Song> getAllSongs(Context context) {
        Cursor cursor1 = context.getContentResolver().query(MediaStore.Audio.Media
                .EXTERNAL_CONTENT_URI, null, null, null, null);
        getSongs(cursor1);
        Cursor cursor2 = context.getContentResolver().query(MediaStore.Audio.Media
                .INTERNAL_CONTENT_URI, null, null, null, null);
        getSongs(cursor2);
        return songs;
    }

    private static void getSongs(Cursor cursor) {
        Song song = null;
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String filename = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio
                        .Media.DISPLAY_NAME));
                String title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio
                        .Media.TITLE));
                int during = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media
                        .DURATION));
                String singer = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio
                        .Media.ARTIST));
                String type = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio
                        .Media.MIME_TYPE));
                String size = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio
                        .Media.SIZE));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio
                        .Media.DATA));
                song = new Song(filename, title, during, singer, type, size, date);
                songs.add(song);
            }
            cursor.close();
        }
    }
}
