package com.example.audio;

public class Song {
    private String filename;
    private String title;
    private int during;
    private String singer;
    private String type;
    private String size;
    private String fileUrl;

    public Song(String filename, String title, int during, String singer, String type, String
            size, String fileUrl) {
        this.filename = filename;
        this.title = title;
        this.during = during;
        this.singer = singer;
        this.type = type;
        this.size = size;
        this.fileUrl = fileUrl;
    }

    public String toString() {
        return "song[filename=" + filename + ", title=" + title + ", during=" + during + ", " +
                "singer=" + singer + ", type=" + type + ", size=" + size + ", fileUrl=" + fileUrl
                + "]";
    }

    public String getFilename() {
        return filename;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getDuring() {
        return during;
    }

    public String getSinger() {
        return singer;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getFileUrl() {
        return fileUrl;
    }
}