package com.example.audio;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Environment;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

import java.io.IOException;

public class MediaService extends Service {
    private static final String FILE_URL = "url";
    private MyBinder mBinder = new MyBinder();
    private String musicPath;
    public MediaPlayer mMediaPlayer = new MediaPlayer();

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        this.musicPath = intent.getStringExtra(FILE_URL);
        iniMediaPlayerFile();
        return mBinder;
    }

    public class MyBinder extends Binder {

        public void playMusic() {
            if (!mMediaPlayer.isPlaying()) {
                mMediaPlayer.start();
            }
        }

        public void pauseMusic() {
            if (mMediaPlayer.isPlaying()) {
                mMediaPlayer.pause();
            }
        }

        public void resetMusic() {
            if (!mMediaPlayer.isPlaying()) {
                mMediaPlayer.reset();
                iniMediaPlayerFile();
            }
        }

        public void closeMedia() {
            if (mMediaPlayer != null) {
                mMediaPlayer.stop();
                mMediaPlayer.release();
            }
        }

        public int getProgress() {
            return mMediaPlayer.getDuration();
        }

        public int getPlayPosition() {
            return mMediaPlayer.getCurrentPosition();
        }

        public void seekToPositon(int msec) {
            mMediaPlayer.seekTo(msec);
        }


    }

    private void iniMediaPlayerFile() {
        try {
            mMediaPlayer.setDataSource(musicPath);
            mMediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
